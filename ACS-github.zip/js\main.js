document.documentElement.classList.add("js");

document.querySelectorAll(".contact-form").forEach((form) => {
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    form.reset();
    alert("Merci. Votre message a bien été reçu.");
  });
});
